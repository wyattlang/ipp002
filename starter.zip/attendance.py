
students = [('Jane', True), ('Jack', False), ('Jill', True), ('Joe', True), ('Jackson', False)]

def take_attendance(students):
    pass
